package org.iesfm.highschool.services;

import org.iesfm.highschool.Group;
import org.iesfm.highschool.Student;
import org.iesfm.highschool.exceptions.GroupNotFoundException;
import org.iesfm.highschool.repository.FaultRepository;
import org.iesfm.highschool.repository.GroupRepository;
import org.iesfm.highschool.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;

@Service
public class StudentService {

    private StudentRepository studentRepository;
    private GroupRepository groupRepository;
    private FaultRepository faultRepository;

    public StudentService(StudentRepository studentRepository, GroupRepository groupRepository, FaultRepository faultRepository) {
        this.studentRepository = studentRepository;
        this.groupRepository = groupRepository;
        this.faultRepository = faultRepository;
    }

    public List<Student> listStudentsFromGroup(int group_id) throws GroupNotFoundException {
        List<Student> students = new LinkedList<>();
        if (!groupRepository.existsById(group_id)) {
            throw new GroupNotFoundException();
        }
        for (Student student : studentRepository.findAll()) {
            if (student.getId_group() == group_id) {
                students.add(student);
            }
        }
        return students;
    }


}
