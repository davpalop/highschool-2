package org.iesfm.highschool.repository;

import org.iesfm.highschool.Fault;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Date;
import java.util.List;

public interface FaultRepository extends MongoRepository<Fault, Date> {

    List<Fault> listFaultsFromStudent(String nif);


}
