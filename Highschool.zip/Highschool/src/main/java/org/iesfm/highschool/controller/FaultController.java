package org.iesfm.highschool.controller;

import org.iesfm.highschool.Fault;
import org.iesfm.highschool.exceptions.FaultNotFoundException;
import org.iesfm.highschool.exceptions.StudentNotFoundException;
import org.iesfm.highschool.services.FaultService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class FaultController {

    private FaultService faultService;

    public FaultController(FaultService faultService) {
        this.faultService = faultService;
    }

    public FaultService getFaultService() {
        return faultService;
    }

    @RequestMapping(method = RequestMethod.GET, path = "students/{nif}/faults")
    public List<Fault> listFaultsFromStudent(String nif) {
        try {
            return faultService.listFaultByStudent(nif);
        } catch (StudentNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No encontrado el estudiante");
        }

    }

}
