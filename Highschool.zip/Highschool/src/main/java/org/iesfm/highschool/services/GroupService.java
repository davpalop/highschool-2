package org.iesfm.highschool.services;


import org.iesfm.highschool.Group;
import org.iesfm.highschool.Student;
import org.iesfm.highschool.repository.GroupRepository;
import org.iesfm.highschool.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupService {

    private GroupRepository groupRepository;
    private StudentRepository studentRepository;

    public GroupService(GroupRepository groupRepository, StudentRepository studentRepository) {
        this.groupRepository = groupRepository;
        this.studentRepository = studentRepository;
    }

    public GroupRepository getGroupRepository() {
        return groupRepository;
    }

    public StudentRepository getStudentRepository() {
        return studentRepository;
    }

    public List<Group> listAllGroups() {
        return groupRepository.findAll();
    }

    public boolean insert(Group group) {
        if (groupRepository.existsById(group.getId())) {
            return false;
        }
        groupRepository.insert(group);
        return true;
    }



}
