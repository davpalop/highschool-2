package org.iesfm.highschool.exceptions;

public class FaultNotFoundException extends Exception{
}
