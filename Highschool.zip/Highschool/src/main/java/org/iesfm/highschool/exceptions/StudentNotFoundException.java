package org.iesfm.highschool.exceptions;

public class StudentNotFoundException extends Exception {
}
