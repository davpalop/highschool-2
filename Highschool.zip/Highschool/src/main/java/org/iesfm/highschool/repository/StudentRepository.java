package org.iesfm.highschool.repository;

import org.iesfm.highschool.Student;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface StudentRepository extends MongoRepository<Student, String > {

    List<Student> listStudentsFromGroup(int group_id);

}
