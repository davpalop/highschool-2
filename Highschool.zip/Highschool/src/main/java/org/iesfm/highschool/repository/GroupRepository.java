package org.iesfm.highschool.repository;

import org.iesfm.highschool.Group;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface GroupRepository extends MongoRepository<Group, Integer> {


}
