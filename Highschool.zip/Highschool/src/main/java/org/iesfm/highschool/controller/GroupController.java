package org.iesfm.highschool.controller;


import org.iesfm.highschool.Group;
import org.iesfm.highschool.services.GroupService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class GroupController {

    private GroupService groupService;

    public GroupController(GroupService groupService) {
        this.groupService = groupService;
    }

    public GroupService getGroupService() {
        return groupService;
    }

    @RequestMapping(method = RequestMethod.GET, path = "/groups")
    public List<Group> listAllGroups() {
        return groupService.listAllGroups();
    }

    @RequestMapping(method = RequestMethod.POST, path = "/groups")
    public void insert(@RequestBody Group group) {
        
    }

}
