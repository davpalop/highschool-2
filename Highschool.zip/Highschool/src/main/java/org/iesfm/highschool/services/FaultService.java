package org.iesfm.highschool.services;

import org.iesfm.highschool.Fault;
import org.iesfm.highschool.Student;
import org.iesfm.highschool.exceptions.StudentNotFoundException;
import org.iesfm.highschool.repository.FaultRepository;
import org.iesfm.highschool.repository.GroupRepository;
import org.iesfm.highschool.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;

@Service
public class FaultService {

    private FaultRepository faultRepository;
    private GroupRepository groupRepository;
    private StudentRepository studentRepository;

    public FaultService(FaultRepository faultRepository, GroupRepository groupRepository, StudentRepository studentRepository) {
        this.faultRepository = faultRepository;
        this.groupRepository = groupRepository;
        this.studentRepository = studentRepository;
    }

    public FaultRepository getFaultRepository() {
        return faultRepository;
    }

    public GroupRepository getGroupRepository() {
        return groupRepository;
    }

    public StudentRepository getStudentRepository() {
        return studentRepository;
    }

    public List<Fault> listFaultByStudent(String nif) throws StudentNotFoundException {
        Student student = studentRepository.findById(nif).get();
        if (!studentRepository.existsById(nif)) {
            throw new StudentNotFoundException();
        } else {
            return student.getFaults();
        }
    }



}
