package org.iesfm.highschool.controller;

import org.iesfm.highschool.Student;
import org.iesfm.highschool.exceptions.GroupNotFoundException;
import org.iesfm.highschool.services.StudentService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class StudentController {

    private StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    public StudentService getStudentService() {
        return studentService;
    }

    @RequestMapping(method = RequestMethod.GET, path = "/groups/{group_id}/students")
    public List<Student> listStudentsFromGroup(int group_id) throws GroupNotFoundException {
        try {
            return studentService.listStudentsFromGroup(group_id);
        } catch (GroupNotFoundException e) {
            throw new GroupNotFoundException();
        }
    }

}
