package org.iesfm.highschool.exceptions;

public class GroupNotFoundException extends Exception{
}
